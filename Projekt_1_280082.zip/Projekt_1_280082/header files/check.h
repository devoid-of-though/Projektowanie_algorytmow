#ifndef CHECK_H
#define CHECK_H
bool check(int* tab, int size);
#endif