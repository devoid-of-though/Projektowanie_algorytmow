#ifndef TIMSORT_H
#define TIMSORT_H
void timsort(int* tab, int leftIndex, int rightIndex);
void merge(int* tab, int leftIndex, int middleIndex, int rightIndex);
#endif //TIMSORT_H
