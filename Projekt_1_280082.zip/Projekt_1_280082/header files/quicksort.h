#ifndef QUICKSORT_H
#define QUICKSORT_H
void quicksort(int* tab, int leftIndex, int rightIndex);
#endif