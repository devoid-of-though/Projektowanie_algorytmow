#ifndef INTROSORT_H
#define INTROSORT_H
void introsort(int* tab, int leftIndex,int rightIndex);
void intro(int* tab, int leftIndex, int rightIndex, int maxdepth);
void insertion(int* tab, int leftIndex, int rightIndex);
int partition(int* tab, int leftIndex, int rightIndex);
#endif